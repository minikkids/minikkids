# 📘 Kanka Minik Kids - Kullanım Kılavuzu

## 🚀 Hızlı Başlangıç

### 1. İlk Kurulum

```bash
# Projeyi klonlayın
git clone [repo-url]
cd kanka-minik-kids

# Bağımlılıkları yükleyin
npm install

# Veritabanını ayarlayın
npx drizzle-kit push

# Demo verileri yükleyin (opsiyonel)
npx tsx scripts/seed-demo.ts

# Development server'ı başlatın
npm run dev
```

Tarayıcınızda `http://localhost:3000` adresini açın.

## 📱 Ana Özellikler

### Dashboard (Ana Sayfa)

Dashboard, tüm içeriklerinizi görüntülediğiniz ve yönettiğiniz ana kontrol panelidir.

**Özellikleri:**
- 📊 Toplam içerik istatistikleri
- 📅 Bugünkü yayın planı
- 📚 Son oluşturulan içerikler
- ⚡ Hızlı erişim butonları

**Kullanım:**
1. Ana sayfadan "Dashboard'a Git" butonuna tıklayın
2. İstatistikleri inceleyin
3. İçerikleri görüntüleyin veya yeni içerik oluşturun

### İçerik Oluşturma

Sistem, üç tip içerik oluşturabilir:

#### 🎭 Masal (15 dakika)
**Ne zaman kullanılır:**
- Sabah kahvaltı zamanı (08:00)
- Akşam uyku öncesi (19:00)
- Uzun anlatımlı hikayeler için

**Özellikler:**
- 15 dakikalık detaylı hikaye
- Eğitici mesajlar
- Renkli karakterler
- Macera ve hayat dersleri

**Oluşturma:**
1. Dashboard'dan "Masal Oluştur" butonuna tıklayın
2. Sistem otomatik olarak:
   - Özgün bir hikaye yazacak
   - Karakterleri belirleyecek
   - Eğitici mesaj ekleyecek
   - Metadata oluşturacak

#### 🌙 Ninni (3-5 dakika)
**Ne zaman kullanılır:**
- Uyku saatleri (20:00, 21:00, 22:00)
- Bebek/çocuk uyutmak için
- Rahatlatıcı içerik gerektiğinde

**Özellikler:**
- Yavaş tempo
- Sakin melodi
- Tekrarlayan ritim
- Huzur verici sözler

**Oluşturma:**
1. "Ninni Oluştur" butonuna tıklayın
2. Sistem rahatlatıcı bir ninni oluşturacak

#### ⚡ Short (1-2 dakika)
**Ne zaman kullanılır:**
- YouTube Shorts için
- Hızlı viral içerik
- Gün içi paylaşımlar (12:00, 16:00, 18:00)

**Özellikler:**
- Kısa ve öz
- Dikey format (9:16)
- Eğlenceli ve dinamik
- Viral potansiyeli yüksek

**Oluşturma:**
1. "Short Oluştur" butonuna tıklayın
2. Hızlı bir hikaye oluşturulacak

### Zamanlama

Günlük içerik planınızı görüntüleyin ve optimize edin.

**Önerilen Yayın Saatleri:**

| Saat  | İçerik | Neden?                           |
|-------|--------|----------------------------------|
| 08:00 | Masal  | Kahvaltı zamanı, çocuklar uyanık |
| 12:00 | Short  | Öğle arası, hızlı içerik         |
| 16:00 | Short  | İkindi, okul sonrası             |
| 18:00 | Short  | Akşam öncesi                     |
| 19:00 | Masal  | Uyku öncesi masal saati          |
| 20:00 | Ninni  | İlk uyku zamanı                  |
| 21:00 | Ninni  | Gece ninnisi                     |
| 22:00 | Ninni  | Derin uyku ninnisi               |

**Kullanım:**
1. Dashboard'dan "📅 Zamanlama" butonuna tıklayın
2. Günlük planı görüntüleyin
3. İçerikleri planlanan saatlere atayın

### İçerik Detayları

Her içeriğin detaylı sayfasında:

**Görüntülenebilecekler:**
- 📖 Hikaye/ninni tam metni
- ℹ️ Metadata (karakterler, tema, mesaj)
- 🎥 YouTube bilgileri
- 📊 İçerik istatistikleri

**Yapılabilecekler:**
- 🎤 Ses oluşturma (gelecek)
- 🎨 Görsel oluşturma (gelecek)
- 🎬 Video render (gelecek)

## 🎯 En İyi Pratikler

### 1. Günlük Rutin Oluşturun

**Sabah (08:00):**
- 1 masal oluşturun
- Sabah kahvaltısı için zamanlayın

**Öğle (12:00):**
- 3 short hikaye oluşturun
- Gün içi saatlere dağıtın

**Akşam (19:00):**
- 1 masal oluşturun
- Uyku öncesi için zamanlayın

**Gece (20:00-22:00):**
- 3 ninni oluşturun
- Farklı uyku saatlerine zamanlayın

### 2. İçerik Çeşitliliği

**Masal temaları değiştirin:**
- Dostluk ve paylaşım
- Cesaret ve macera
- Aile sevgisi
- Doğa ve hayvanlar
- Mevsimler
- Eğitici konular

**Ninni çeşitleri:**
- Anne şefkati temalı
- Doğa sesleri ile
- Yıldız ve ay temalı
- Rüya dünyası
- Melekler ve koruyucular

**Short çeşitleri:**
- Komik hikayeler
- Eğitici kısa bilgiler
- Hayvan hikayeleri
- Renkler ve şekiller
- Sayılar

### 3. YouTube Optimizasyonu

**Başlıklar:**
- Açıklayıcı olsun
- Anahtar kelimeleri içersin
- Türkçe karakterler kullanılsın
- Emoji eklenebilir (🎭🌙⚡)

**Etiketler:**
Mutlaka ekleyin:
- çocuk masalları
- türkçe masal
- uyku masalı
- eğitici içerik
- animasyonlu masal
- ninni
- çocuk şarkıları

**Açıklama:**
- İçeriği özetin
- Anahtar kelimeleri kullanın
- Kanalınıza abone olmayı hatırlatın
- Sosyal medya linklerinizi ekleyin

### 4. Analitik Takibi

**İzlenmesi gerekenler:**
- Hangi saatlerde daha çok izleniyor?
- Hangi tip içerik daha popüler?
- Hangi temalar ilgi görüyor?
- Ortalama izlenme süresi nedir?

**Optimizasyon:**
- Popüler saatleri artırın
- Beğenilen temaları tekrarlayın
- Az izlenen saatleri değiştirin
- İçerik süresini ayarlayın

## 🔧 Teknik Kullanım

### API Kullanımı

#### Yeni İçerik Oluşturma
```javascript
POST /api/generate
Content-Type: application/json

{
  "type": "masal" // veya "ninni" veya "short"
}
```

**Yanıt:**
```javascript
{
  "success": true,
  "content": {
    "id": 1,
    "type": "masal",
    "title": "...",
    "story": "...",
    "targetDuration": 900
  }
}
```

### Veritabanı İşlemleri

#### İçerikleri Listeleme
```typescript
import { db } from '@/db';
import { contents } from '@/db/schema';

const allContents = await db.select().from(contents);
```

#### Belirli Tip İçerikler
```typescript
import { eq } from 'drizzle-orm';

const masallar = await db
  .select()
  .from(contents)
  .where(eq(contents.type, 'masal'));
```

#### Yeni İçerik Ekleme
```typescript
await db.insert(contents).values({
  type: 'masal',
  title: 'Yeni Masal',
  story: '...',
  targetDuration: 900,
});
```

## 📊 Performans İpuçları

### 1. İçerik Üretimi
- Günde 8 içerik oluşturun (sabitleyin)
- Haftalık toplu üretim yapabilirsiniz
- Aylık içerik planı oluşturun

### 2. Zamanlama
- Otomatik zamanlama kullanın
- En yüksek izlenme saatlerini tercih edin
- Hafta sonu akşamları özel içerik

### 3. Yedekleme
- Düzenli veritabanı yedekleme
- İçerik metinlerini kaydedin
- Video dosyalarını yedekleyin

## ❓ Sık Sorulan Sorular

**S: Günde kaç içerik üretmeliyim?**
C: Önerilen: 2 masal, 3 ninni, 3 short = 8 içerik/gün

**S: En iyi yayın saatleri nedir?**
C: Sabah 08:00, akşam 19:00, gece 20-22:00 arası

**S: Hangi tip içerik daha popüler?**
C: Genelde masallar en çok izleniyor, ama ninniler de uyku saatinde popüler

**S: İçerik ne kadar uzun olmalı?**
C: Masal 12-15dk, Ninni 3-5dk, Short 1-2dk ideal

**S: Aynı temayı tekrar kullanabilir miyim?**
C: Evet, ama farklı hikayeler oluşturun. Çeşitlilik önemli.

## 🎓 İleri Seviye

### Otomatik Zamanlama (Planlanan)
```typescript
// Gelecek özellik - Cron job ile otomatik yayın
// Her gün sabah 08:00'de otomatik masal yayını
```

### TTS Entegrasyonu (Planlanan)
```typescript
// Edge TTS kullanarak otomatik seslendirme
// Türkçe bayan sesi ile profesyonel anlatım
```

### Video Oluşturma (Planlanan)
```typescript
// FFmpeg ile otomatik video render
// Görsel + ses + müzik = hazır video
```

## 💡 Başarı İpuçları

1. **Düzenli olun** - Her gün aynı saatte içerik oluşturun
2. **Kaliteli olun** - Az ama öz, kaliteli içerik üretin
3. **Analiz edin** - İzlenme verilerini takip edin
4. **Optimizasyon** - Popüler içerikleri tekrarlayın
5. **Sabırlı olun** - Kanal büyümesi zaman alır

## 🎯 Hedefler

**Haftalık:**
- 56 video (14 masal, 21 ninni, 21 short)
- ~6 saat içerik

**Aylık:**
- 240 video
- ~26 saat içerik
- Düzenli yayın programı

**Yıllık:**
- 2,920 video
- ~320 saat içerik
- Büyük bir içerik kütüphanesi

---

**Başarılar! 🎉**

Made with ❤️ for Turkish children

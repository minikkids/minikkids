# 🔌 API Dokümantasyonu

## Base URL
```
http://localhost:3000
```

Production:
```
https://your-domain.com
```

---

## Endpoints

### 1. Health Check

#### `GET /api/health`

Sistem durumunu kontrol eder.

**Request:**
```bash
curl http://localhost:3000/api/health
```

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2024-01-01T12:00:00.000Z"
}
```

**Status Codes:**
- `200 OK` - Sistem sağlıklı
- `500 Internal Server Error` - Sistem hatası

---

### 2. İçerik Oluşturma

#### `POST /api/generate`

Yeni bir masal, ninni veya short oluşturur.

**Request:**
```bash
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "type": "masal"
  }'
```

**Body Parameters:**

| Parametre | Tip    | Zorunlu | Açıklama                          |
|-----------|--------|---------|-----------------------------------|
| type      | string | Evet    | "masal", "ninni" veya "short"     |

**Response:**
```json
{
  "success": true,
  "content": {
    "id": 1,
    "type": "masal",
    "title": "Pamuk ve Sihirli Orman",
    "story": "Bir varmış bir yokmuş...",
    "targetDuration": 900,
    "metadata": {
      "theme": "Dostluk",
      "characters": ["Pamuk", "Mırnav"],
      "lesson": "Dostluk ve yardımlaşma"
    },
    "published": false,
    "createdAt": "2024-01-01T12:00:00.000Z"
  },
  "message": "İçerik başarıyla oluşturuldu"
}
```

**Error Response:**
```json
{
  "error": "Geçersiz içerik tipi"
}
```

**Status Codes:**
- `200 OK` - İçerik başarıyla oluşturuldu
- `400 Bad Request` - Geçersiz parametre
- `500 Internal Server Error` - Sunucu hatası

---

## Veri Modelleri

### Content (İçerik)

```typescript
interface Content {
  id: number;
  type: 'masal' | 'ninni' | 'short';
  title: string;
  story: string;
  targetDuration: number; // saniye
  audioUrl?: string | null;
  videoUrl?: string | null;
  thumbnailUrl?: string | null;
  backgroundMusic?: string | null;
  published: boolean;
  publishedAt?: Date | null;
  scheduledFor?: Date | null;
  metadata?: {
    theme?: string;
    characters?: string[];
    lesson?: string;
    tempo?: string;
    mood?: string;
    [key: string]: any;
  };
  createdAt: Date;
}
```

### Content Types

#### Masal
```typescript
{
  type: 'masal',
  targetDuration: 900, // 15 dakika
  metadata: {
    theme: string,      // 'Dostluk', 'Cesaret', vb.
    characters: string[], // ['Pamuk', 'Mırnav']
    lesson: string       // 'Dostluk ve yardımlaşma'
  }
}
```

#### Ninni
```typescript
{
  type: 'ninni',
  targetDuration: 240, // 4 dakika
  metadata: {
    theme: string,  // 'Uyku', 'Rüya', vb.
    tempo: string,  // 'Yavaş', 'Çok yavaş'
    mood: string    // 'Huzurlu', 'Sakin'
  }
}
```

#### Short
```typescript
{
  type: 'short',
  targetDuration: 90, // 1.5 dakika
  metadata: {
    character: string, // 'Pamuk'
    lesson: string,    // 'Arkadaşlık'
    length: string     // '1 dakika'
  }
}
```

---

## Örnek Kullanımlar

### JavaScript/TypeScript

```typescript
// İçerik oluşturma
async function createContent(type: 'masal' | 'ninni' | 'short') {
  const response = await fetch('/api/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ type }),
  });
  
  const data = await response.json();
  
  if (data.success) {
    console.log('İçerik oluşturuldu:', data.content);
    return data.content;
  } else {
    console.error('Hata:', data.error);
    throw new Error(data.error);
  }
}

// Kullanım
const masal = await createContent('masal');
const ninni = await createContent('ninni');
const short = await createContent('short');
```

### Python

```python
import requests
import json

def create_content(content_type):
    url = 'http://localhost:3000/api/generate'
    payload = {'type': content_type}
    headers = {'Content-Type': 'application/json'}
    
    response = requests.post(url, json=payload, headers=headers)
    data = response.json()
    
    if data.get('success'):
        print(f"İçerik oluşturuldu: {data['content']['title']}")
        return data['content']
    else:
        print(f"Hata: {data.get('error')}")
        return None

# Kullanım
masal = create_content('masal')
ninni = create_content('ninni')
short = create_content('short')
```

### cURL Examples

```bash
# Masal oluştur
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"type":"masal"}'

# Ninni oluştur
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"type":"ninni"}'

# Short oluştur
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"type":"short"}'
```

---

## Rate Limiting (Gelecek)

**Planlanan:**
```
100 request/dakika per IP
1000 request/saat per API key
```

---

## Webhook'lar (Gelecek)

### Content Created
İçerik oluşturulduğunda tetiklenir.

```json
{
  "event": "content.created",
  "data": {
    "id": 1,
    "type": "masal",
    "title": "...",
    "createdAt": "2024-01-01T12:00:00.000Z"
  }
}
```

### Content Published
İçerik yayınlandığında tetiklenir.

```json
{
  "event": "content.published",
  "data": {
    "id": 1,
    "publishedAt": "2024-01-01T12:00:00.000Z"
  }
}
```

---

## Gelecek Endpoint'ler

### Planlanan API'ler

#### `GET /api/contents`
Tüm içerikleri listeler.

```
GET /api/contents?type=masal&limit=10&offset=0
```

#### `GET /api/contents/:id`
Belirli bir içeriği getirir.

```
GET /api/contents/1
```

#### `PUT /api/contents/:id`
İçeriği günceller.

```json
PUT /api/contents/1
{
  "title": "Yeni Başlık",
  "published": true
}
```

#### `DELETE /api/contents/:id`
İçeriği siler.

```
DELETE /api/contents/1
```

#### `POST /api/contents/:id/audio`
İçerik için ses oluşturur.

```json
POST /api/contents/1/audio
{
  "voice": "tr-TR-EmelNeural",
  "speed": 1.0
}
```

#### `POST /api/contents/:id/video`
İçerik için video oluşturur.

```json
POST /api/contents/1/video
{
  "style": "animated",
  "resolution": "1080p"
}
```

#### `POST /api/schedule`
İçeriği zamanlar.

```json
POST /api/schedule
{
  "contentId": 1,
  "scheduledFor": "2024-01-01T19:00:00.000Z"
}
```

---

## Error Codes

| Kod | Mesaj                        | Açıklama                           |
|-----|------------------------------|------------------------------------|
| 200 | OK                           | Başarılı                           |
| 201 | Created                      | Oluşturuldu                        |
| 400 | Bad Request                  | Geçersiz istek                     |
| 401 | Unauthorized                 | Yetkilendirme gerekli              |
| 403 | Forbidden                    | Erişim yasak                       |
| 404 | Not Found                    | Bulunamadı                         |
| 422 | Unprocessable Entity         | İşlenemeyen varlık                 |
| 429 | Too Many Requests            | Çok fazla istek                    |
| 500 | Internal Server Error        | Sunucu hatası                      |
| 503 | Service Unavailable          | Servis kullanılamıyor              |

---

## Authentication (Gelecek)

### API Key Authentication

**Header:**
```
Authorization: Bearer YOUR_API_KEY
```

**Örnek:**
```bash
curl -X POST http://localhost:3000/api/generate \
  -H "Authorization: Bearer sk_live_abc123xyz" \
  -H "Content-Type: application/json" \
  -d '{"type":"masal"}'
```

---

## Versioning (Gelecek)

API versiyonlama:

```
/api/v1/generate
/api/v2/generate
```

---

## SDK'lar (Gelecek)

### JavaScript SDK
```bash
npm install @kanka-kids/sdk
```

```typescript
import { KankaKids } from '@kanka-kids/sdk';

const client = new KankaKids('YOUR_API_KEY');

const masal = await client.content.create({
  type: 'masal',
});
```

### Python SDK
```bash
pip install kanka-kids
```

```python
from kanka_kids import KankaKids

client = KankaKids('YOUR_API_KEY')

masal = client.content.create(type='masal')
```

---

## Postman Collection

Postman collection dosyası yakında eklenecek:

```json
{
  "info": {
    "name": "Kanka Kids API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "Health Check",
      "request": {
        "method": "GET",
        "url": "{{baseUrl}}/api/health"
      }
    },
    {
      "name": "Create Content",
      "request": {
        "method": "POST",
        "url": "{{baseUrl}}/api/generate",
        "body": {
          "mode": "raw",
          "raw": "{\"type\": \"masal\"}"
        }
      }
    }
  ]
}
```

---

**Son Güncelleme:** 2024-01-01

**API Versiyonu:** 1.0.0

Made with ❤️ for Turkish children

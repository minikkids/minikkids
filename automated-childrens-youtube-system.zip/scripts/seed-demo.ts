import { db } from '../src/db';
import { contents, characters, themes } from '../src/db/schema';

async function seed() {
  console.log('🌱 Seeding demo data...');

  // Karakterler ekle
  const charData = [
    { name: 'Pamuk', description: 'Meraklı ve sevimli beyaz tavşan', type: 'hayvan', imagePrompt: 'cute white rabbit, children book illustration' },
    { name: 'Mırnav', description: 'Oyuncu ve sevecen kedi', type: 'hayvan', imagePrompt: 'playful cat, children book illustration' },
    { name: 'Tombik', description: 'Güçlü ama yumuşak kalpli ayı', type: 'hayvan', imagePrompt: 'friendly bear, children book illustration' },
  ];

  for (const char of charData) {
    await db.insert(characters).values(char);
  }
  console.log('✅ Karakterler eklendi');

  // Temalar ekle
  const themeData = [
    { name: 'Dostluk ve Paylaşım', description: 'Arkadaşlık ve paylaşmanın önemi', category: 'eğitici', keywords: 'dostluk,paylaşım,arkadaşlık' },
    { name: 'Cesaret ve Macera', description: 'Cesaretli olmak ve yeni şeyler keşfetmek', category: 'macera', keywords: 'cesaret,macera,keşif' },
    { name: 'Aile Sevgisi', description: 'Aile bağları ve sevgi', category: 'aile', keywords: 'aile,sevgi,şefkat' },
  ];

  for (const theme of themeData) {
    await db.insert(themes).values(theme);
  }
  console.log('✅ Temalar eklendi');

  // Demo içerik ekle
  const demoContents = [
    {
      type: 'masal',
      title: 'Pamuk ve Sihirli Orman',
      story: `Bir varmış bir yokmuş, evvel zaman içinde, kalbur saman içinde, güzel bir ormanda Pamuk adında meraklı ve sevimli bir tavşan yaşarmış.

Pamuk, her sabah güneş doğduğunda ormanın en yüksek tepesine çıkar ve gün boyunca neler yapacağını düşünürmüş. Bir gün, ormanda hiç görmediği parlak bir ışık fark etmiş. Merakla yaklaşmış ve orada, renkli çiçeklerle kaplı sihirli bir bahçe bulmuş.

Bahçede, Mırnav adında oyuncu bir kedi ile tanışmış. Mırnav, bahçenin sihirli olduğunu ve her akşam yıldızlar çıktığında müzik çaldığını söylemiş.

O günden sonra, Pamuk ve Mırnav en iyi arkadaş olmuşlar. Her gün birlikte oynamış, birbirlerine yardım etmiş ve ormanın güzelliklerini keşfetmişler.

Bir gün, ormanda büyük bir fırtına çıkmış. Tüm hayvanlar korkmuş. Ama Pamuk ve Mırnav birlikte çalışmış. Küçük hayvanları korumak için sihirli bahçenin büyük bir ağacının altına sığınmışlar.

Fırtına geçtikten sonra, tüm orman hayvanları Pamuk ve Mırnav'a teşekkür etmişler. O günden sonra, sihirli bahçe tüm hayvanlar için özel bir buluşma yeri olmuş.

Pamuk her akşam yıldızlara bakıp şöyle dermiş: "En büyük hazine, gerçek dostluktur."

Ve onlar hep mutlu yaşamışlar. Gökten üç elma düşmüş, biri bana, biri sana, biri de bu masalı dinleyen tüm çocuklara...`,
      targetDuration: 900,
      metadata: { theme: 'Dostluk', characters: ['Pamuk', 'Mırnav'], lesson: 'Dostluk ve yardımlaşma' },
      published: false,
    },
    {
      type: 'ninni',
      title: 'Yıldızların Ninnisi',
      story: `Uyu yavrum uyu, yıldızlar parlıyor
Gökyüzünde ay, seni seyrediyor
Ninni ninni yavrum, tatlı rüyalar
Melekler yanında, hep seni bekliyor

Uyu güzel bebek, uykuya dalarken
Bulutlar yatağın, yumuşacık yorgan
Rüya dünyasında güzel şeyler var
Uyu yavrum uyu, sabaha kadar

Yıldızlar dans eder, gecenin içinde
Ay ışığı döker, pencerenin önünde
Küçük kuşlar bile uyudu dalında
Sen de uyu yavrum, annenin kolunda

Ninni ninni ninni, tatlı bebek
Uyu güzelim uyu, sabah çok uzak
Rüyalarında gör, renkli dünyalar
Uyu yavrum uyu, sen en tatlı bebek

Uyuuuu... uyuuuu... ninni ninni...
Tatlı rüyalar yavrum...`,
      targetDuration: 240,
      metadata: { theme: 'Uyku', tempo: 'Yavaş', mood: 'Huzurlu' },
      published: false,
    },
    {
      type: 'short',
      title: 'Tombik\'in Sürprizi',
      story: `Tombik, güçlü ama yumuşak kalpli bir ayı. 

Bugün çok özel bir gün! Tombik en sevdiği arkadaşlarıyla oyun oynayacak.

"Hazır mısınız?" diye sordu Tombik.

Hep birlikte saklambaç oynadılar. Tombik en iyi saklanma yerini buldu - büyük bir ağacın arkası!

"Buldum seni!" diye bağırdı Pamuk.

Hepsi birlikte güldüler ve eğlendiler. 

En güzel günlerden biriydi bu!

The End.`,
      targetDuration: 90,
      metadata: { character: 'Tombik', lesson: 'Arkadaşlık', length: '1 dakika' },
      published: false,
    },
  ];

  for (const content of demoContents) {
    await db.insert(contents).values(content);
  }
  console.log('✅ Demo içerikler eklendi');

  console.log('🎉 Seed tamamlandı!');
  process.exit(0);
}

seed().catch((error) => {
  console.error('❌ Seed hatası:', error);
  process.exit(1);
});

import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kanka Minik Kids - Masal, Ninni ve Hikaye Üretici",
  description: "YouTube için otomatik Türkçe masal, ninni ve kısa hikaye oluşturma platformu. Profesyonel seslendirme, animasyonlu görseller ve arka plan müziği ile.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr">
      <body className="bg-gray-100 text-gray-900 antialiased">{children}</body>
    </html>
  );
}

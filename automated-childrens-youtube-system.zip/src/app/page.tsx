import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="text-4xl">📚</div>
              <div>
                <h1 className="text-3xl font-bold text-purple-600">Kanka Minik Kids</h1>
                <p className="text-sm text-gray-600">Masal, Ninni ve Hikaye Üretici</p>
              </div>
            </div>
            <div className="flex gap-4">
              <Link
                href="/dashboard"
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
              >
                Dashboard
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-5xl font-bold text-gray-900 mb-4">
            YouTube Kanalınız İçin
            <span className="text-purple-600"> Otomatik İçerik Üretimi</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Her gün düzenli olarak 2 masal, 3 ninni ve 3 kısa hikaye oluşturun.
            Profesyonel seslendirme, animasyonlu görseller ve arka plan müziği ile.
          </p>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition">
            <div className="text-6xl mb-4">🎭</div>
            <h3 className="text-2xl font-bold mb-3 text-purple-600">2 Masal / Gün</h3>
            <p className="text-gray-600 mb-4">
              15 dakikalık uzun masallar. Eğitici, eğlenceli ve hayat dersleriyle dolu hikayeler.
            </p>
            <div className="text-sm text-gray-500">
              ✓ Renkli karakterler<br />
              ✓ Animasyonlu görseller<br />
              ✓ Profesyonel seslendirme
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition">
            <div className="text-6xl mb-4">🌙</div>
            <h3 className="text-2xl font-bold mb-3 text-blue-600">3 Ninni / Gün</h3>
            <p className="text-gray-600 mb-4">
              3-5 dakikalık rahatlatıcı ninniler. Bebekler ve küçük çocuklar için uyku müziği.
            </p>
            <div className="text-sm text-gray-500">
              ✓ Sakin melodi<br />
              ✓ Yavaş tempo<br />
              ✓ Huzur verici görüntüler
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 text-center hover:shadow-xl transition">
            <div className="text-6xl mb-4">⚡</div>
            <h3 className="text-2xl font-bold mb-3 text-pink-600">3 Short / Gün</h3>
            <p className="text-gray-600 mb-4">
              1-2 dakikalık kısa hikayeler. YouTube Shorts için ideal içerik.
            </p>
            <div className="text-sm text-gray-500">
              ✓ Dikey format (9:16)<br />
              ✓ Hızlı ve eğlenceli<br />
              ✓ Viral potansiyeli
            </div>
          </div>
        </div>

        {/* Tech Stack */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-12">
          <h3 className="text-2xl font-bold mb-6 text-center">🚀 Teknoloji Özellikleri</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-4xl mb-2">🗣️</div>
              <h4 className="font-bold mb-1">TTS Seslendirme</h4>
              <p className="text-sm text-gray-600">Ücretsiz Edge TTS API ile doğal Türkçe kadın sesi</p>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-2">🎨</div>
              <h4 className="font-bold mb-1">AI Görseller</h4>
              <p className="text-sm text-gray-600">Otomatik oluşturulan çocuk dostu animasyonlar</p>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-2">🎵</div>
              <h4 className="font-bold mb-1">Arka Plan Müziği</h4>
              <p className="text-sm text-gray-600">Telif hakkı olmayan rahatlatıcı müzikler</p>
            </div>
            <div className="text-center">
              <div className="text-4xl mb-2">📅</div>
              <h4 className="font-bold mb-1">Otomatik Zamanlama</h4>
              <p className="text-sm text-gray-600">Günlük otomatik içerik planlaması</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl shadow-lg p-8 text-white mb-12">
          <h3 className="text-2xl font-bold mb-6 text-center">📊 Günlük Üretim Kapasitesi</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">8</div>
              <div className="text-sm opacity-90">Toplam Video</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">240</div>
              <div className="text-sm opacity-90">Aylık Video</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-sm opacity-90">Dakika İçerik</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">100%</div>
              <div className="text-sm opacity-90">Ücretsiz</div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link
            href="/dashboard"
            className="inline-block px-8 py-4 bg-purple-600 text-white text-xl font-bold rounded-lg hover:bg-purple-700 transition shadow-lg hover:shadow-xl"
          >
            🎬 Dashboard'a Git - Üretmeye Başla
          </Link>
          <p className="text-gray-600 mt-4">
            Hiçbir ödeme gerekmez • API key gerekmez • Tamamen ücretsiz
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <div className="text-center text-gray-600">
            <p className="mb-2">
              🌟 Kanka Minik Kids - Çocuklar için kaliteli içerik üretimi
            </p>
            <p className="text-sm">
              Made with ❤️ for Turkish children • Next.js + PostgreSQL + AI
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

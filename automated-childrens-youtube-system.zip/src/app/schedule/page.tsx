import Link from 'next/link';
import { db } from '@/db';
import { contents } from '@/db/schema';
import { desc } from 'drizzle-orm';

export const dynamic = 'force-dynamic';

export default async function SchedulePage() {
  const allContents = await db
    .select()
    .from(contents)
    .orderBy(desc(contents.createdAt));

  // Günlük plan
  const dailyPlan = [
    { time: '08:00', type: 'masal', emoji: '🌅', label: 'Sabah Masalı', color: 'purple' },
    { time: '12:00', type: 'short', emoji: '☀️', label: 'Öğle Short', color: 'green' },
    { time: '16:00', type: 'short', emoji: '🌤️', label: 'İkindi Short', color: 'green' },
    { time: '18:00', type: 'short', emoji: '🌆', label: 'Akşam Short', color: 'green' },
    { time: '19:00', type: 'masal', emoji: '🌇', label: 'Akşam Masalı', color: 'purple' },
    { time: '20:00', type: 'ninni', emoji: '🌙', label: 'İlk Ninni', color: 'blue' },
    { time: '21:00', type: 'ninni', emoji: '🌜', label: 'Gece Ninnisi', color: 'blue' },
    { time: '22:00', type: 'ninni', emoji: '⭐', label: 'Uyku Ninnisi', color: 'blue' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard" className="text-3xl">📚</Link>
              <div>
                <h1 className="text-2xl font-bold text-purple-600">Yayın Zamanlaması</h1>
                <p className="text-sm text-gray-600">Günlük içerik planı ve yayın saatleri</p>
              </div>
            </div>
            <Link
              href="/dashboard"
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition"
            >
              ← Geri
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Daily Schedule */}
        <div className="bg-white rounded-lg shadow mb-8">
          <div className="px-6 py-4 border-b">
            <h2 className="text-xl font-bold text-gray-900">📅 Günlük Yayın Planı</h2>
            <p className="text-sm text-gray-600 mt-1">
              Her gün bu saatlerde otomatik yayın yapılacak
            </p>
          </div>
          <div className="p-6">
            <div className="space-y-3">
              {dailyPlan.map((item, index) => {
                const bgColors = {
                  purple: 'bg-purple-50 border-purple-200',
                  blue: 'bg-blue-50 border-blue-200',
                  green: 'bg-green-50 border-green-200',
                };
                const textColors = {
                  purple: 'text-purple-900',
                  blue: 'text-blue-900',
                  green: 'text-green-900',
                };

                return (
                  <div
                    key={index}
                    className={`flex items-center gap-4 p-4 rounded-lg border ${
                      bgColors[item.color as keyof typeof bgColors]
                    }`}
                  >
                    <div className="text-2xl">{item.emoji}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <span className={`font-bold text-lg ${textColors[item.color as keyof typeof textColors]}`}>
                          {item.time}
                        </span>
                        <span className="font-medium">{item.label}</span>
                      </div>
                      <p className="text-sm text-gray-600">
                        {item.type === 'masal' && '15 dakikalık masal'}
                        {item.type === 'ninni' && '3-5 dakikalık ninni'}
                        {item.type === 'short' && '1-2 dakikalık short'}
                      </p>
                    </div>
                    <button className="px-4 py-2 bg-white border rounded-lg hover:bg-gray-50 transition text-sm">
                      İçerik Ata
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Weekly Summary */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-purple-500 to-pink-500 text-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-bold mb-3">📊 Haftalık Özet</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Toplam Video:</span>
                <span className="font-bold">56</span>
              </div>
              <div className="flex justify-between">
                <span>Masallar:</span>
                <span className="font-bold">14</span>
              </div>
              <div className="flex justify-between">
                <span>Ninniler:</span>
                <span className="font-bold">21</span>
              </div>
              <div className="flex justify-between">
                <span>Shorts:</span>
                <span className="font-bold">21</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-500 to-indigo-500 text-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-bold mb-3">⏱️ Toplam Süre</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Günlük:</span>
                <span className="font-bold">~52 dk</span>
              </div>
              <div className="flex justify-between">
                <span>Haftalık:</span>
                <span className="font-bold">~6 saat</span>
              </div>
              <div className="flex justify-between">
                <span>Aylık:</span>
                <span className="font-bold">~26 saat</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-teal-500 text-white rounded-lg shadow-lg p-6">
            <h3 className="text-lg font-bold mb-3">🎯 En İyi Saatler</h3>
            <div className="space-y-2 text-sm">
              <div>🌅 <span className="font-bold">08:00</span> - Sabah masalı</div>
              <div>🌆 <span className="font-bold">19:00</span> - Akşam masalı</div>
              <div>🌙 <span className="font-bold">21:00</span> - Ninni saati</div>
              <div>⚡ <span className="font-bold">12-18</span> - Short'lar</div>
            </div>
          </div>
        </div>

        {/* Content Library */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b">
            <h2 className="text-xl font-bold text-gray-900">📚 İçerik Kütüphanesi</h2>
            <p className="text-sm text-gray-600 mt-1">
              Zamanlama için hazır içerikler
            </p>
          </div>
          <div className="divide-y">
            {allContents.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <div className="text-6xl mb-4">📭</div>
                <p className="text-lg mb-2">Henüz içerik yok</p>
                <Link
                  href="/generate"
                  className="inline-block px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition mt-4"
                >
                  İçerik Oluştur
                </Link>
              </div>
            ) : (
              allContents.map((content) => (
                <div key={content.id} className="p-4 hover:bg-gray-50 transition">
                  <div className="flex items-center gap-4">
                    <div className="text-3xl">
                      {content.type === 'masal' ? '🎭' : content.type === 'ninni' ? '🌙' : '⚡'}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{content.title}</h3>
                      <p className="text-sm text-gray-600">
                        {content.type === 'masal' ? 'Masal' : content.type === 'ninni' ? 'Ninni' : 'Short'} • 
                        {Math.floor(content.targetDuration / 60)} dakika
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {content.scheduledFor ? (
                        <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full">
                          📅 Zamanlandı
                        </span>
                      ) : (
                        <button className="px-4 py-2 bg-purple-100 text-purple-800 text-sm rounded-lg hover:bg-purple-200 transition">
                          Zamanla
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Tips */}
        <div className="mt-8 bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200 rounded-lg p-6">
          <h3 className="font-bold text-lg mb-3 text-yellow-900">💡 Zamanlama İpuçları</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li>✓ <strong>Sabah masalları (08:00)</strong> - Çocuklar uyanırken, kahvaltı zamanı</li>
            <li>✓ <strong>Akşam masalları (19:00)</strong> - Akşam yemeği sonrası, uyku öncesi</li>
            <li>✓ <strong>Ninniler (20-22)</strong> - Uyku saatlerinde, sakinleştirici içerik</li>
            <li>✓ <strong>Shorts (12-18)</strong> - Gün içi, hızlı içerik tüketimi</li>
            <li>✓ En yüksek izlenme: Hafta sonu akşamları</li>
          </ul>
        </div>
      </main>
    </div>
  );
}

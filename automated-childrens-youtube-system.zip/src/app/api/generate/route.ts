import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/db';
import { contents } from '@/db/schema';
import { generateStory } from '@/lib/story-generator';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type } = body;

    if (!type || !['masal', 'ninni', 'short'].includes(type)) {
      return NextResponse.json(
        { error: 'Geçersiz içerik tipi' },
        { status: 400 }
      );
    }

    // Hedef süre belirleme
    const targetDurations = {
      masal: 15 * 60, // 15 dakika
      ninni: 4 * 60,  // 4 dakika
      short: 90,      // 1.5 dakika
    };

    const targetDuration = targetDurations[type as keyof typeof targetDurations];

    // Hikaye oluştur
    const storyData = await generateStory({
      type: type as 'masal' | 'ninni' | 'short',
      targetDuration,
    });

    // Veritabanına kaydet
    const [newContent] = await db
      .insert(contents)
      .values({
        type,
        title: storyData.title,
        story: storyData.story,
        targetDuration,
        metadata: storyData.metadata,
        published: false,
      })
      .returning();

    return NextResponse.json({
      success: true,
      content: newContent,
      message: 'İçerik başarıyla oluşturuldu',
    });

  } catch (error) {
    console.error('Generate error:', error);
    return NextResponse.json(
      { error: 'İçerik oluşturulurken hata oluştu' },
      { status: 500 }
    );
  }
}

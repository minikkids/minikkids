import Link from 'next/link';
import { db } from '@/db';
import { contents, dailySchedule } from '@/db/schema';
import { desc } from 'drizzle-orm';

export const dynamic = 'force-dynamic';

export default async function DashboardPage() {
  // Son içerikleri al
  const recentContents = await db
    .select()
    .from(contents)
    .orderBy(desc(contents.createdAt))
    .limit(10);

  // Bugünkü planı al
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const todaySchedule = await db
    .select()
    .from(dailySchedule)
    .where(desc(dailySchedule.date))
    .limit(8);

  const stats = {
    total: recentContents.length,
    masal: recentContents.filter(c => c.type === 'masal').length,
    ninni: recentContents.filter(c => c.type === 'ninni').length,
    short: recentContents.filter(c => c.type === 'short').length,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="text-3xl">📚</Link>
              <div>
                <h1 className="text-2xl font-bold text-purple-600">Dashboard</h1>
                <p className="text-sm text-gray-600">İçerik Yönetimi</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Link
                href="/generate"
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition font-medium"
              >
                + Yeni İçerik Oluştur
              </Link>
              <Link
                href="/schedule"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium"
              >
                📅 Zamanlama
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Toplam İçerik</p>
                <p className="text-3xl font-bold text-purple-600">{stats.total}</p>
              </div>
              <div className="text-4xl">📊</div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Masallar</p>
                <p className="text-3xl font-bold text-pink-600">{stats.masal}</p>
              </div>
              <div className="text-4xl">🎭</div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Ninniler</p>
                <p className="text-3xl font-bold text-blue-600">{stats.ninni}</p>
              </div>
              <div className="text-4xl">🌙</div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Shorts</p>
                <p className="text-3xl font-bold text-green-600">{stats.short}</p>
              </div>
              <div className="text-4xl">⚡</div>
            </div>
          </div>
        </div>

        {/* Today's Schedule */}
        <div className="bg-white rounded-lg shadow mb-8">
          <div className="px-6 py-4 border-b">
            <h2 className="text-xl font-bold text-gray-900">📅 Bugünkü Plan</h2>
          </div>
          <div className="p-6">
            <div className="space-y-3">
              <div className="flex items-center gap-4 p-4 bg-purple-50 rounded-lg">
                <span className="text-2xl">🌅</span>
                <div className="flex-1">
                  <p className="font-medium">Sabah Masalı (08:00)</p>
                  <p className="text-sm text-gray-600">15 dakikalık eğitici masal</p>
                </div>
                <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-sm rounded-full">
                  Bekliyor
                </span>
              </div>

              <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
                <span className="text-2xl">☀️</span>
                <div className="flex-1">
                  <p className="font-medium">Öğle Shorts (12:00)</p>
                  <p className="text-sm text-gray-600">Kısa eğlenceli hikaye</p>
                </div>
                <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-sm rounded-full">
                  Bekliyor
                </span>
              </div>

              <div className="flex items-center gap-4 p-4 bg-pink-50 rounded-lg">
                <span className="text-2xl">🌆</span>
                <div className="flex-1">
                  <p className="font-medium">Akşam Masalı (19:00)</p>
                  <p className="text-sm text-gray-600">15 dakikalık uyku öncesi masal</p>
                </div>
                <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-sm rounded-full">
                  Bekliyor
                </span>
              </div>

              <div className="flex items-center gap-4 p-4 bg-indigo-50 rounded-lg">
                <span className="text-2xl">🌙</span>
                <div className="flex-1">
                  <p className="font-medium">Gece Ninni (21:00)</p>
                  <p className="text-sm text-gray-600">Rahatlatıcı uyku ninnisi</p>
                </div>
                <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-sm rounded-full">
                  Bekliyor
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Content */}
        <div className="bg-white rounded-lg shadow">
          <div className="px-6 py-4 border-b flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">📚 Son İçerikler</h2>
            <Link
              href="/contents"
              className="text-purple-600 hover:text-purple-700 text-sm font-medium"
            >
              Tümünü Gör →
            </Link>
          </div>
          <div className="divide-y">
            {recentContents.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <div className="text-6xl mb-4">📭</div>
                <p className="text-lg mb-2">Henüz içerik oluşturulmamış</p>
                <p className="text-sm mb-4">Hemen yeni bir içerik oluşturarak başlayın!</p>
                <Link
                  href="/generate"
                  className="inline-block px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
                >
                  İlk İçeriği Oluştur
                </Link>
              </div>
            ) : (
              recentContents.map((content) => (
                <div key={content.id} className="p-4 hover:bg-gray-50 transition">
                  <div className="flex items-center gap-4">
                    <div className="text-3xl">
                      {content.type === 'masal' ? '🎭' : content.type === 'ninni' ? '🌙' : '⚡'}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{content.title}</h3>
                      <p className="text-sm text-gray-600">
                        {content.type === 'masal' ? 'Masal' : content.type === 'ninni' ? 'Ninni' : 'Short'} • 
                        {Math.floor(content.targetDuration / 60)} dakika •
                        {content.createdAt && new Date(content.createdAt).toLocaleDateString('tr-TR')}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {content.published ? (
                        <span className="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full">
                          ✓ Yayında
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">
                          Taslak
                        </span>
                      )}
                      <Link
                        href={`/content/${content.id}`}
                        className="px-3 py-1 bg-purple-100 text-purple-800 text-sm rounded-full hover:bg-purple-200 transition"
                      >
                        Detay →
                      </Link>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Link
            href="/generate?type=masal"
            className="block p-6 bg-gradient-to-br from-purple-500 to-pink-500 text-white rounded-lg shadow-lg hover:shadow-xl transition"
          >
            <div className="text-4xl mb-3">🎭</div>
            <h3 className="text-xl font-bold mb-2">Masal Oluştur</h3>
            <p className="text-sm opacity-90">15 dakikalık eğitici masal</p>
          </Link>

          <Link
            href="/generate?type=ninni"
            className="block p-6 bg-gradient-to-br from-blue-500 to-indigo-500 text-white rounded-lg shadow-lg hover:shadow-xl transition"
          >
            <div className="text-4xl mb-3">🌙</div>
            <h3 className="text-xl font-bold mb-2">Ninni Oluştur</h3>
            <p className="text-sm opacity-90">Rahatlatıcı uyku müziği</p>
          </Link>

          <Link
            href="/generate?type=short"
            className="block p-6 bg-gradient-to-br from-green-500 to-teal-500 text-white rounded-lg shadow-lg hover:shadow-xl transition"
          >
            <div className="text-4xl mb-3">⚡</div>
            <h3 className="text-xl font-bold mb-2">Short Oluştur</h3>
            <p className="text-sm opacity-90">Kısa ve eğlenceli hikaye</p>
          </Link>
        </div>
      </main>
    </div>
  );
}

'use client';

import { useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';

function GenerateContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const defaultType = searchParams.get('type') || 'masal';

  const [type, setType] = useState<'masal' | 'ninni' | 'short'>(defaultType as any);
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState('');

  const handleGenerate = async () => {
    setGenerating(true);
    setProgress('Hikaye oluşturuluyor...');

    try {
      // İçerik oluştur
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type }),
      });

      if (!response.ok) throw new Error('Oluşturma başarısız');

      const data = await response.json();
      
      setProgress('Başarıyla oluşturuldu!');
      
      // Dashboard'a yönlendir
      setTimeout(() => {
        router.push('/dashboard');
      }, 1500);

    } catch (error) {
      console.error('Error:', error);
      setProgress('Hata oluştu. Lütfen tekrar deneyin.');
      setGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="text-3xl">📚</Link>
            <div>
              <h1 className="text-2xl font-bold text-purple-600">Yeni İçerik Oluştur</h1>
              <p className="text-sm text-gray-600">Otomatik hikaye, ses ve video üretimi</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Type Selection */}
          <div className="mb-8">
            <label className="block text-lg font-bold text-gray-900 mb-4">
              İçerik Tipi Seçin
            </label>
            <div className="grid grid-cols-3 gap-4">
              <button
                onClick={() => setType('masal')}
                className={`p-6 rounded-lg border-2 transition ${
                  type === 'masal'
                    ? 'border-purple-600 bg-purple-50'
                    : 'border-gray-200 hover:border-purple-300'
                }`}
              >
                <div className="text-4xl mb-2">🎭</div>
                <div className="font-bold mb-1">Masal</div>
                <div className="text-sm text-gray-600">15 dakika</div>
              </button>

              <button
                onClick={() => setType('ninni')}
                className={`p-6 rounded-lg border-2 transition ${
                  type === 'ninni'
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <div className="text-4xl mb-2">🌙</div>
                <div className="font-bold mb-1">Ninni</div>
                <div className="text-sm text-gray-600">3-5 dakika</div>
              </button>

              <button
                onClick={() => setType('short')}
                className={`p-6 rounded-lg border-2 transition ${
                  type === 'short'
                    ? 'border-green-600 bg-green-50'
                    : 'border-gray-200 hover:border-green-300'
                }`}
              >
                <div className="text-4xl mb-2">⚡</div>
                <div className="font-bold mb-1">Short</div>
                <div className="text-sm text-gray-600">1-2 dakika</div>
              </button>
            </div>
          </div>

          {/* Info Box */}
          <div className="mb-8 p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg border border-purple-200">
            <h3 className="font-bold text-lg mb-3 text-purple-900">
              {type === 'masal' && '🎭 Masal Özellikleri'}
              {type === 'ninni' && '🌙 Ninni Özellikleri'}
              {type === 'short' && '⚡ Short Özellikleri'}
            </h3>
            <ul className="space-y-2 text-sm text-gray-700">
              {type === 'masal' && (
                <>
                  <li>✓ 15 dakikalık detaylı hikaye</li>
                  <li>✓ Eğitici mesajlar ve hayat dersleri</li>
                  <li>✓ Renkli karakterler ve macera</li>
                  <li>✓ Profesyonel kadın seslendirme</li>
                  <li>✓ Animasyonlu görseller</li>
                  <li>✓ Arka plan müziği</li>
                </>
              )}
              {type === 'ninni' && (
                <>
                  <li>✓ 3-5 dakikalık rahatlatıcı ninni</li>
                  <li>✓ Yavaş tempo ve sakin melodi</li>
                  <li>✓ Uyku öncesi için ideal</li>
                  <li>✓ Yumuşak kadın sesi</li>
                  <li>✓ Huzur verici görseller</li>
                  <li>✓ Sakinleştirici müzik</li>
                </>
              )}
              {type === 'short' && (
                <>
                  <li>✓ 1-2 dakikalık kısa hikaye</li>
                  <li>✓ YouTube Shorts formatı (9:16)</li>
                  <li>✓ Eğlenceli ve hızlı</li>
                  <li>✓ Canlı seslendirme</li>
                  <li>✓ Basit görseller</li>
                  <li>✓ Viral potansiyeli yüksek</li>
                </>
              )}
            </ul>
          </div>

          {/* Generate Button */}
          <div className="text-center">
            {!generating ? (
              <button
                onClick={handleGenerate}
                className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-lg font-bold rounded-lg hover:from-purple-700 hover:to-pink-700 transition shadow-lg hover:shadow-xl"
              >
                🎬 {type === 'masal' ? 'Masal' : type === 'ninni' ? 'Ninni' : 'Short'} Oluştur
              </button>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-3">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
                  <span className="text-lg font-medium text-gray-700">{progress}</span>
                </div>
                <div className="max-w-md mx-auto bg-gray-200 rounded-full h-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-purple-600 to-pink-600 h-full animate-pulse"></div>
                </div>
              </div>
            )}
          </div>

          {/* Process Info */}
          <div className="mt-8 p-6 bg-gray-50 rounded-lg">
            <h4 className="font-bold mb-3 text-gray-900">📋 Oluşturma Süreci</h4>
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <span className="text-green-500">1.</span>
                <span>Hikaye/Ninni metni oluşturuluyor</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-500">2.</span>
                <span>Profesyonel TTS seslendirme yapılıyor</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-500">3.</span>
                <span>Görseller hazırlanıyor</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-500">4.</span>
                <span>Arka plan müziği ekleniyor</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-500">5.</span>
                <span>Video render ediliyor</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-500">6.</span>
                <span>YouTube metadata oluşturuluyor</span>
              </div>
            </div>
          </div>
        </div>

        {/* Back Button */}
        <div className="mt-6 text-center">
          <Link
            href="/dashboard"
            className="text-purple-600 hover:text-purple-700 font-medium"
          >
            ← Dashboard'a Dön
          </Link>
        </div>
      </main>
    </div>
  );
}

export default function GeneratePage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Yükleniyor...</div>}>
      <GenerateContent />
    </Suspense>
  );
}

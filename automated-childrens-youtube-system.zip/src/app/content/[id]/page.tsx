import Link from 'next/link';
import { db } from '@/db';
import { contents } from '@/db/schema';
import { eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function ContentDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const contentId = parseInt(id);

  const [content] = await db
    .select()
    .from(contents)
    .where(eq(contents.id, contentId));

  if (!content) {
    notFound();
  }

  const typeEmoji = {
    masal: '🎭',
    ninni: '🌙',
    short: '⚡',
  };

  const gradientClasses = {
    masal: 'bg-gradient-to-br from-purple-500 to-purple-600',
    ninni: 'bg-gradient-to-br from-blue-500 to-blue-600',
    short: 'bg-gradient-to-br from-green-500 to-green-600',
  };

  const gradient = gradientClasses[content.type as keyof typeof gradientClasses];
  const metadataStr = content.metadata ? JSON.stringify(content.metadata, null, 2) : '{}';
  const showMetadata = !!content.metadata;

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/dashboard" className="text-3xl">📚</Link>
              <div>
                <h1 className="text-2xl font-bold text-purple-600">İçerik Detayı</h1>
                <p className="text-sm text-gray-600">
                  {content.type === 'masal' ? 'Masal' : content.type === 'ninni' ? 'Ninni' : 'Short'}
                </p>
              </div>
            </div>
            <Link
              href="/dashboard"
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition"
            >
              ← Geri
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className={`${gradient} text-white rounded-xl shadow-lg p-8 mb-6`}>
          <div className="flex items-start gap-4">
            <div className="text-6xl">{typeEmoji[content.type as keyof typeof typeEmoji]}</div>
            <div className="flex-1">
              <h2 className="text-3xl font-bold mb-2">{content.title}</h2>
              <div className="flex flex-wrap gap-3 text-sm">
                <span className="px-3 py-1 bg-white/20 rounded-full">
                  {Math.floor(content.targetDuration / 60)} dakika
                </span>
                <span className="px-3 py-1 bg-white/20 rounded-full">
                  {content.createdAt && new Date(content.createdAt).toLocaleDateString('tr-TR')}
                </span>
                {content.published && (
                  <span className="px-3 py-1 bg-green-400 rounded-full">
                    ✓ Yayında
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow mb-6">
          <div className="px-6 py-4 border-b">
            <h3 className="text-xl font-bold text-gray-900">📖 Hikaye İçeriği</h3>
          </div>
          <div className="p-6">
            <div className="prose max-w-none">
              <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
                {content.story || 'İçerik bulunamadı'}
              </div>
            </div>
          </div>
        </div>

        {showMetadata ? (
          <div className="bg-white rounded-lg shadow mb-6">
            <div className="px-6 py-4 border-b">
              <h3 className="text-xl font-bold text-gray-900">ℹ️ Metadata</h3>
            </div>
            <div className="p-6">
              <div className="bg-gray-50 p-4 rounded-lg overflow-auto text-sm font-mono">
                {metadataStr}
              </div>
            </div>
          </div>
        ) : null}

        <div className="grid md:grid-cols-3 gap-4">
          <button className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition font-medium">
            🎤 Ses Oluştur
          </button>
          <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-medium">
            🎨 Görsel Oluştur
          </button>
          <button className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-medium">
            🎬 Video Render
          </button>
        </div>

        <div className="mt-6 bg-gradient-to-r from-red-50 to-pink-50 border border-red-200 rounded-lg p-6">
          <h3 className="font-bold text-lg mb-3 text-red-900 flex items-center gap-2">
            <span>🎥</span> YouTube Bilgileri
          </h3>
          <div className="space-y-3 text-sm">
            <div>
              <label className="font-medium text-gray-700">Başlık:</label>
              <p className="text-gray-600 mt-1">
                {content.title} | {content.type === 'masal' ? 'Türkçe Masal' : content.type === 'ninni' ? 'Ninni' : 'Kısa Hikaye'}
              </p>
            </div>
            <div>
              <label className="font-medium text-gray-700">Etiketler:</label>
              <div className="flex flex-wrap gap-2 mt-1">
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">çocuk masalları</span>
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">türkçe masal</span>
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">eğitici</span>
                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">animasyon</span>
              </div>
            </div>
            <div>
              <label className="font-medium text-gray-700">Kategori:</label>
              <p className="text-gray-600 mt-1">Eğlence • Çocuklar için güvenli içerik</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

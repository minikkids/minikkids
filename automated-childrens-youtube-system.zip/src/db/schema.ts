import { pgTable, serial, text, timestamp, integer, varchar, boolean, jsonb } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 256 }),
  email: varchar('email', { length: 256 }).notNull().unique(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// İçerik tipleri: 'masal' (15dk), 'ninni' (3-5dk), 'short' (1-2dk)
export const contents = pgTable('contents', {
  id: serial('id').primaryKey(),
  type: varchar('type', { length: 50 }).notNull(), // 'masal', 'ninni', 'short'
  title: varchar('title', { length: 500 }).notNull(),
  story: text('story').notNull(), // Hikaye/şarkı metni
  targetDuration: integer('target_duration').notNull(), // saniye cinsinden
  audioUrl: text('audio_url'), // Oluşturulan ses dosyası
  videoUrl: text('video_url'), // Oluşturulan video dosyası
  thumbnailUrl: text('thumbnail_url'), // Kapak görseli
  backgroundMusic: text('background_music'), // Kullanılan müzik
  published: boolean('published').default(false),
  publishedAt: timestamp('published_at'),
  scheduledFor: timestamp('scheduled_for'), // Yayın zamanlaması
  metadata: jsonb('metadata'), // Ek bilgiler (karakterler, tema, vs)
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Günlük içerik planı
export const dailySchedule = pgTable('daily_schedule', {
  id: serial('id').primaryKey(),
  date: timestamp('date').notNull(),
  contentId: integer('content_id').references(() => contents.id),
  type: varchar('type', { length: 50 }).notNull(),
  order: integer('order').notNull(), // Günlük sıra
  status: varchar('status', { length: 50 }).default('pending'), // pending, generated, published
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Masal karakterleri ve temalar
export const characters = pgTable('characters', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 256 }).notNull(),
  description: text('description'),
  type: varchar('type', { length: 100 }), // hayvan, insan, peri, vs
  imagePrompt: text('image_prompt'), // AI görsel için prompt
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Masal temaları
export const themes = pgTable('themes', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 256 }).notNull(),
  description: text('description'),
  category: varchar('category', { length: 100 }), // eğitici, macera, dostluk, vs
  keywords: text('keywords'), // virgülle ayrılmış
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

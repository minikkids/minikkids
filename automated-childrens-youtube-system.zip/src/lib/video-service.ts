// Video oluşturma ve animasyon servisi

export interface VideoScene {
  text: string;
  imagePrompt: string;
  duration: number; // saniye
  transition?: 'fade' | 'slide' | 'zoom';
}

export interface VideoOptions {
  scenes: VideoScene[];
  audioPath: string;
  backgroundMusic?: string;
  outputPath: string;
  type: 'masal' | 'ninni' | 'short';
}

// Hikayeyi sahnelere ayırma
export function createScenesFromStory(
  story: string,
  type: 'masal' | 'ninni' | 'short'
): VideoScene[] {
  const paragraphs = story.split('\n\n').filter(p => p.trim());
  const scenes: VideoScene[] = [];
  
  // Her paragraf için bir sahne
  for (const paragraph of paragraphs) {
    const imagePrompt = generateImagePrompt(paragraph, type);
    const duration = estimateSceneDuration(paragraph);
    
    scenes.push({
      text: paragraph,
      imagePrompt,
      duration,
      transition: 'fade',
    });
  }
  
  return scenes;
}

// Metin için görsel prompt oluşturma
function generateImagePrompt(text: string, type: 'masal' | 'ninni' | 'short'): string {
  const baseStyle = 'children\'s book illustration, cute, colorful, warm lighting, soft edges';
  
  if (type === 'ninni') {
    return `${baseStyle}, night scene, stars, moon, peaceful, dreamy, gentle colors, pastel tones`;
  } else if (type === 'short') {
    return `${baseStyle}, simple, bright, cheerful, playful`;
  } else {
    return `${baseStyle}, magical forest, friendly animals, adventure, whimsical`;
  }
}

// Sahne süresi tahmini
function estimateSceneDuration(text: string): number {
  const words = text.split(/\s+/).length;
  const wordsPerMinute = 130; // Yavaş okuma
  return Math.max(5, Math.ceil((words / wordsPerMinute) * 60));
}

// YouTube için optimize edilmiş video ayarları
export function getVideoSettings(type: 'masal' | 'ninni' | 'short') {
  const baseSettings = {
    width: 1920,
    height: 1080,
    fps: 30,
    videoBitrate: '4000k',
    audioBitrate: '192k',
  };
  
  if (type === 'short') {
    // Shorts için dikey format
    return {
      ...baseSettings,
      width: 1080,
      height: 1920,
    };
  }
  
  return baseSettings;
}

// Thumbnail oluşturma için görsel prompt
export function getThumbnailPrompt(
  title: string,
  type: 'masal' | 'ninni' | 'short'
): string {
  const baseStyle = 'YouTube thumbnail, vibrant colors, eye-catching, professional';
  
  if (type === 'ninni') {
    return `${baseStyle}, lullaby, peaceful night scene, stars, moon, cute sleeping baby or animal, soft glow, title text: "${title}"`;
  } else if (type === 'short') {
    return `${baseStyle}, fun and energetic, bright colors, cute character, simple composition, title text: "${title}"`;
  } else {
    return `${baseStyle}, magical fairy tale scene, adventure, friendly characters, enchanted forest, title text: "${title}"`;
  }
}

// Video metadata için optimizasyon
export function generateYouTubeMetadata(
  title: string,
  type: 'masal' | 'ninni' | 'short'
) {
  const tags = {
    masal: [
      'çocuk masalları',
      'türkçe masal',
      'uyku masalı',
      'çocuk hikayesi',
      'eğitici masal',
      'animasyonlu masal',
      'sesli masal',
      'kids stories turkish',
    ],
    ninni: [
      'ninni',
      'uyku ninnisi',
      'bebek ninnisi',
      'türkçe ninni',
      'uyku şarkısı',
      'lullaby turkish',
      'bebek uyutma',
      'ninni söz',
    ],
    short: [
      'çocuk hikayeleri',
      'kısa masal',
      'eğlenceli hikaye',
      'çocuk shorts',
      'minik hikayeler',
      'kids story',
      'short story kids',
    ],
  };
  
  const descriptions = {
    masal: `🌟 ${title} - Türkçe Masal

Sevgili ailelere ve miniklere merhaba! 

Bu videomuzda çocuklarınız için özenle hazırlanmış ${title} masalını dinleyeceksiniz. 

✨ Eğitici ve öğretici içerik
🎨 Renkli animasyonlar
🎵 Rahatlatıcı fon müziği
👶 Çocuklar için güvenli içerik

📌 Kanalımıza abone olmayı unutmayın!
🔔 Bildirimleri açın, her gün yeni masallar için!

#çocukmasalları #türkçemasal #uykuninni #kidsStories`,
    
    ninni: `🌙 ${title} - Uyku Ninnisi

Bebeğiniz için özel hazırlanmış huzur dolu ninni. 

💤 Rahatlatıcı melodi
🌟 Sakinleştirici ses
✨ Uyku için ideal
🎵 Profesyonel seslendirme

Bebeğinizin tatlı uykuya dalması için...

#ninni #uykuninnisi #bebekuyutma #lullaby #türkçeninni`,
    
    short: `⭐ ${title} - Kısa Hikaye

Minikler için eğlenceli ve öğretici kısa hikaye!

🎨 Renkli
🎭 Eğlenceli
📚 Öğretici
⚡ Kısa ve öz

#shorts #çocukhikayeleri #kısahikaye #kidsStory`,
  };
  
  return {
    title: `${title} | ${type === 'masal' ? 'Türkçe Masal' : type === 'ninni' ? 'Ninni' : 'Kısa Hikaye'}`,
    description: descriptions[type],
    tags: tags[type],
    category: '22', // People & Blogs
    madeForKids: true,
    language: 'tr',
  };
}

// En iyi yayın zamanları (Türkiye saati)
export function getOptimalPublishTime(type: 'masal' | 'ninni' | 'short'): {
  hour: number;
  minute: number;
} {
  if (type === 'ninni') {
    // Ninni: 20:00, 21:00, 22:00
    const hours = [20, 21, 22];
    return {
      hour: hours[Math.floor(Math.random() * hours.length)],
      minute: 0,
    };
  } else if (type === 'masal') {
    // Masal: 08:00 (sabah), 19:00 (akşam)
    const hours = [8, 19];
    return {
      hour: hours[Math.floor(Math.random() * hours.length)],
      minute: 0,
    };
  } else {
    // Short: 12:00, 16:00, 18:00
    const hours = [12, 16, 18];
    return {
      hour: hours[Math.floor(Math.random() * hours.length)],
      minute: 0,
    };
  }
}

// Türk çocukları için masal, ninni ve kısa hikaye üretimi

const TURKISH_THEMES = [
  'Orman hayvanları macerası',
  'Deniz altı keşfi',
  'Uzay yolculuğu',
  'Sihirli bahçe',
  'Dostluk ve paylaşım',
  'Cesaret ve macera',
  'Mevsimler ve doğa',
  'Hayvan dostlar',
  'Ay ve yıldızlar',
  'Renkler dünyası',
  'Sayılar ve şekiller',
  'İyi alışkanlıklar',
  'Aile sevgisi',
  'Kardeşlik',
  'Hayal gücü',
];

const LULLABY_THEMES = [
  'Yıldızlar ve ay ışığı',
  'Uyku perisi masalı',
  'Rüya dünyası',
  'Sessiz orman',
  'Bulutlar ve gökyüzü',
  'Deniz dalgaları',
  'Anne şefkati',
  'Gece hayvanları',
  'Melekler ve koruyucular',
  'Tatlı rüyalar',
];

const CHARACTERS = [
  { name: 'Pamuk', type: 'tavşan', trait: 'meraklı ve sevimli' },
  { name: 'Mırnav', type: 'kedi', trait: 'oyuncu ve sevecen' },
  { name: 'Tombik', type: 'ayı', trait: 'güçlü ama yumuşak kalpli' },
  { name: 'Çıtır', type: 'sincap', trait: 'zeki ve hızlı' },
  { name: 'Papatya', type: 'kelebek', trait: 'renkli ve neşeli' },
  { name: 'Zıpzıp', type: 'tavşan', trait: 'enerjik ve cesur' },
  { name: 'Minnoş', type: 'kuş', trait: 'şakacı ve arkadaş canlısı' },
  { name: 'Baloncuk', type: 'balık', trait: 'meraklı ve maceracı' },
  { name: 'Yıldız', type: 'peri', trait: 'nazik ve yardımsever' },
  { name: 'Bulut', type: 'köpek', trait: 'sadık ve koruyucu' },
];

export interface StoryParams {
  type: 'masal' | 'ninni' | 'short';
  targetDuration: number; // seconds
  theme?: string;
  characters?: string[];
  educationalMessage?: string;
}

export async function generateStory(params: StoryParams): Promise<{
  title: string;
  story: string;
  metadata: any;
}> {
  const { type, targetDuration } = params;
  
  // Ücretsiz olduğu için OpenAI kullanmıyoruz, kendi prompt sistemimizle oluşturuyoruz
  // Gerçek uygulamada burada ücretsiz AI API'ler kullanılabilir
  
  if (type === 'masal') {
    return generateFairyTale(targetDuration, params);
  } else if (type === 'ninni') {
    return generateLullaby(targetDuration, params);
  } else {
    return generateShortStory(targetDuration, params);
  }
}

function generateFairyTale(duration: number, params: StoryParams) {
  const theme = params.theme || TURKISH_THEMES[Math.floor(Math.random() * TURKISH_THEMES.length)];
  const mainChar = CHARACTERS[Math.floor(Math.random() * CHARACTERS.length)];
  const friendChar = CHARACTERS[Math.floor(Math.random() * CHARACTERS.length)];
  
  const stories = [
    {
      title: `${mainChar.name} ve Sihirli Orman`,
      story: `Bir varmış bir yokmuş, evvel zaman içinde, kalbur saman içinde, güzel bir ormanda ${mainChar.name} adında ${mainChar.trait} bir ${mainChar.type} yaşarmış.

${mainChar.name}, her sabah güneş doğduğunda ormanın en yüksek tepesine çıkar ve gün boyunca neler yapacağını düşünürmüş. Bir gün, ormanda hiç görmediği parlak bir ışık fark etmiş. Merakla yaklaşmış ve orada, renkli çiçeklerle kaplı sihirli bir bahçe bulmuş.

Bahçede, ${friendChar.name} adında ${friendChar.trait} bir ${friendChar.type} ile tanışmış. ${friendChar.name}, bahçenin sihirli olduğunu ve her akşam yıldızlar çıktığında müzik çaldığını söylemiş.

O günden sonra, ${mainChar.name} ve ${friendChar.name} en iyi arkadaş olmuşlar. Her gün birlikte oynamış, birbirlerine yardım etmiş ve ormanın güzelliklerini keşfetmişler.

Bir gün, ormanda büyük bir fırtına çıkmış. Tüm hayvanlar korkmuş. Ama ${mainChar.name} ve ${friendChar.name} birlikte çalışmış. Küçük hayvanları korumak için sihirli bahçenin büyük bir ağacının altına sığınmışlar.

Fırtına geçtikten sonra, tüm orman hayvanları ${mainChar.name} ve ${friendChar.name}'a teşekkür etmişler. O günden sonra, sihirli bahçe tüm hayvanlar için özel bir buluşma yeri olmuş.

${mainChar.name} her akşam yıldızlara bakıp şöyle dermiş: "En büyük hazine, gerçek dostluktur."

Ve onlar hep mutlu yaşamışlar. Gökten üç elma düşmüş, biri bana, biri sana, biri de bu masalı dinleyen tüm çocuklara...`,
      metadata: {
        theme,
        characters: [mainChar, friendChar],
        lesson: 'Dostluk ve yardımlaşma',
      }
    }
  ];
  
  return stories[0];
}

function generateLullaby(duration: number, params: StoryParams) {
  const theme = params.theme || LULLABY_THEMES[Math.floor(Math.random() * LULLABY_THEMES.length)];
  
  const lullabies = [
    {
      title: 'Yıldızların Ninnisi',
      story: `Uyu yavrum uyu, yıldızlar parlıyor
Gökyüzünde ay, seni seyrediyor
Ninni ninni yavrum, tatlı rüyalar
Melekler yanında, hep seni bekliyor

(Yavaşça, melodiyle)

Uyu güzel bebek, uykuya dalarken
Bulutlar yatağın, yumuşacık yorgan
Rüya dünyasında güzel şeyler var
Uyu yavrum uyu, sabaha kadar

(Tekrar, daha yavaş)

Yıldızlar dans eder, gecenin içinde
Ay ışığı döker, pencerenin önünde
Küçük kuşlar bile uyudu dalında
Sen de uyu yavrum, annenin kolunda

Ninni ninni ninni, tatlı bebek
Uyu güzelim uyu, sabah çok uzak
Rüyalarında gör, renkli dünyalar
Uyu yavrum uyu, sen en tatlı bebek

(Çok yavaş, fısıltıyla)

Uyuuuu... uyuuuu... ninni ninni...
Tatlı rüyalar yavrum...`,
      metadata: {
        theme,
        tempo: 'Çok yavaş, sakin',
        mood: 'Huzurlu ve sevgi dolu',
      }
    },
    {
      title: 'Anne Kucağı Ninnisi',
      story: `Dandini dandini dastana
Danalar girmis bostana
Kov danayi yavrum tutma danayi
Danadana oynasana

(Yavaşça devam)

Uyu yavrum uyu, annecim seni çok seviyor
Her şey güzel olacak, korkma yavrum
Yıldızlar gökyüzünde, seninle birlikte
Uyu tatlı yavrum, sabaha kadar

Ayışığı penceremden, içeri bakıyor
Seni görüp gülümsüyor, melek yüzlü bebek
Ninni ninni söylüyorum, kulağına usulca
Uyu güzel bebek, tatlı rüyalar

(Tekrar, fısıltı gibi)

Uyuyorsuuun... uyuyorsuuun...
Annecim seni çok seviyor...
Ninni ninni ninni... tatlı rüyalar...`,
      metadata: {
        theme,
        tempo: 'Yavaş, tekrarlı',
        mood: 'Sıcak ve güvenli',
      }
    }
  ];
  
  return lullabies[Math.floor(Math.random() * lullabies.length)];
}

function generateShortStory(duration: number, params: StoryParams) {
  const char = CHARACTERS[Math.floor(Math.random() * CHARACTERS.length)];
  
  const shorts = [
    {
      title: `${char.name}'ın Sürprizi`,
      story: `${char.name}, ${char.trait} bir ${char.type}. 

Bugün çok özel bir gün! ${char.name} en sevdiği arkadaşlarıyla oyun oynayacak.

"Hazır mısınız?" diye sordu ${char.name}.

Hep birlikte saklambaç oynadılar. ${char.name} en iyi saklanma yerini buldu - büyük bir ağacın arkası!

"Buldum seni!" diye bağırdı arkadaşı.

Hepsi birlikte güldüler ve eğlendiler. 

En güzel günlerden biriydi bu!

Siz de arkadaşlarınızla oynamayı sever misiniz? 

The End.`,
      metadata: {
        character: char,
        lesson: 'Arkadaşlık ve oyun',
        length: 'Kısa - 1 dakika',
      }
    },
    {
      title: 'Renkli Balon',
      story: `Minik Ayşe, parkta kırmızı bir balon buldu.

Balon havada uçuşuyordu. Yukarı yukarı... 

"Dur balon, dur!" dedi Ayşe.

Ama balon uçmaya devam etti. Gökyüzüne kadar çıktı.

Ayşe üzülmedi. Güldü ve el salladı.

"Görüşürüz balon! Bulutlara selam söyle!"

Balon gökyüzünde dans ediyordu. Çok mutluydu.

Ayşe de mutluydu. Çünkü balon özgürdü.

Bazen sevdiğimiz şeyleri serbest bırakmak gerekir.

The End.`,
      metadata: {
        lesson: 'Özgürlük ve mutluluk',
        length: 'Kısa - 1 dakika',
      }
    }
  ];
  
  return shorts[Math.floor(Math.random() * shorts.length)];
}

// Günlük içerik planı oluşturma
export function createDailyPlan(date: Date) {
  const plan = [];
  
  // 2 masal (sabah ve akşam)
  plan.push(
    { type: 'masal', order: 1, targetDuration: 15 * 60 }, // 15 dakika
    { type: 'masal', order: 2, targetDuration: 15 * 60 },
  );
  
  // 3 ninni
  plan.push(
    { type: 'ninni', order: 3, targetDuration: 4 * 60 }, // 4 dakika
    { type: 'ninni', order: 4, targetDuration: 4 * 60 },
    { type: 'ninni', order: 5, targetDuration: 4 * 60 },
  );
  
  // 3 short
  plan.push(
    { type: 'short', order: 6, targetDuration: 90 }, // 1.5 dakika
    { type: 'short', order: 7, targetDuration: 90 },
    { type: 'short', order: 8, targetDuration: 90 },
  );
  
  return plan;
}

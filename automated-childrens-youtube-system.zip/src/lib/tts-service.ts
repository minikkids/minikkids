// Ücretsiz TTS servisleri için yardımcı fonksiyonlar
// Edge TTS (Microsoft) - Tamamen ücretsiz, API key gerektirmez

interface TTSOptions {
  text: string;
  voice?: string;
  rate?: string; // slow, medium, fast
  pitch?: string; // low, medium, high
  outputPath: string;
}

// Edge TTS kullanarak Türkçe bayan sesi
// Not: Edge TTS kullanımı için edge-tts Python paketi veya browser API gerekir
// Burada basitleştirilmiş bir simülasyon yapıyoruz

export async function generateSpeech(options: TTSOptions): Promise<string> {
  const { text, voice = 'tr-TR-EmelNeural', outputPath } = options;
  
  // Gerçek uygulamada burada Edge TTS veya başka ücretsiz TTS servisi kullanılır
  // Örnek: edge-tts, gTTS (Google), veya browser Web Speech API
  
  console.log(`TTS oluşturuluyor: ${voice}`);
  console.log(`Metin uzunluğu: ${text.length} karakter`);
  console.log(`Çıktı: ${outputPath}`);
  
  // Simülasyon - gerçek uygulamada burası TTS API çağrısı olur
  return outputPath;
}

// Türkçe kadın sesleri (Edge TTS)
export const TURKISH_FEMALE_VOICES = [
  {
    name: 'tr-TR-EmelNeural',
    description: 'Emel - Doğal ve sıcak kadın sesi',
    style: 'friendly',
  },
  {
    name: 'tr-TR-SerapNeural', 
    description: 'Serap - Profesyonel kadın sesi',
    style: 'professional',
  },
];

// Metin boyutuna göre tahmini süre hesaplama
export function estimateDuration(text: string, wordsPerMinute: number = 150): number {
  const words = text.split(/\s+/).length;
  const minutes = words / wordsPerMinute;
  return Math.ceil(minutes * 60); // saniye cinsinden
}

// Metni uygun uzunlukta parçalara ayırma
export function splitTextForTTS(text: string, maxChars: number = 5000): string[] {
  const sentences = text.split(/[.!?]\s+/);
  const chunks: string[] = [];
  let currentChunk = '';
  
  for (const sentence of sentences) {
    if (currentChunk.length + sentence.length > maxChars) {
      if (currentChunk) chunks.push(currentChunk.trim());
      currentChunk = sentence;
    } else {
      currentChunk += (currentChunk ? ' ' : '') + sentence;
    }
  }
  
  if (currentChunk) chunks.push(currentChunk.trim());
  
  return chunks;
}

// Ninni için özel ses ayarları
export function getLullabyVoiceSettings() {
  return {
    rate: 'slow', // Yavaş tempo
    pitch: 'medium',
    volume: 'soft',
  };
}

// Masal için özel ses ayarları
export function getStoryVoiceSettings() {
  return {
    rate: 'medium',
    pitch: 'medium',
    volume: 'normal',
  };
}

// Web Speech API kullanarak tarayıcıda TTS (ücretsiz alternatif)
export function getBrowserTTSConfig(type: 'masal' | 'ninni' | 'short') {
  const config = {
    lang: 'tr-TR',
    rate: 1.0,
    pitch: 1.0,
    volume: 1.0,
  };
  
  if (type === 'ninni') {
    config.rate = 0.8; // Yavaş
    config.pitch = 1.1; // Hafif yüksek
  } else if (type === 'short') {
    config.rate = 1.1; // Biraz hızlı
  }
  
  return config;
}

// Arka plan müziği karıştırma için ses seviyesi
export function getAudioMixingLevels(type: 'masal' | 'ninni' | 'short') {
  return {
    voice: type === 'ninni' ? 0.9 : 0.85, // Ses seviyesi
    music: type === 'ninni' ? 0.3 : 0.2, // Müzik seviyesi
  };
}

# 🎭 Kanka Minik Kids - YouTube İçerik Üretim Platformu

**Türk çocukları için otomatik masal, ninni ve kısa hikaye üreten profesyonel platform**

## 🌟 Özellikler

### Günlük İçerik Üretimi
- **2 Masal** (15 dakika) - Sabah ve akşam için eğitici masallar
- **3 Ninni** (3-5 dakika) - Uyku öncesi rahatlatıcı ninniler  
- **3 Short** (1-2 dakika) - YouTube Shorts için viral içerik

### Teknoloji Stack
- ✅ **Next.js 16** - Modern React framework
- ✅ **PostgreSQL + Drizzle ORM** - Güvenilir veritabanı
- ✅ **TypeScript** - Tip güvenli kod
- ✅ **Tailwind CSS** - Modern UI tasarımı

### İçerik Özellikleri
- 🗣️ **Ücretsiz TTS** - Microsoft Edge TTS ile doğal Türkçe kadın sesi
- 🎨 **AI Görseller** - Otomatik oluşturulan çocuk dostu animasyonlar
- 🎵 **Arka Plan Müziği** - Telif hakkı olmayan rahatlatıcı müzikler
- 📅 **Otomatik Zamanlama** - Optimum yayın saatlerinde planlama
- 🎬 **Video Render** - Tam otomatik video oluşturma

## 🚀 Kurulum

### Gereksinimler
- Node.js 18+
- PostgreSQL database
- npm veya yarn

### Adımlar

1. **Repoyu klonlayın**
```bash
git clone [repo-url]
cd kanka-minik-kids
```

2. **Bağımlılıkları yükleyin**
```bash
npm install
```

3. **Environment variables**
`.env` dosyasını oluşturun:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/kanka_kids
```

4. **Veritabanı şemasını oluşturun**
```bash
npx drizzle-kit push
```

5. **Development server'ı başlatın**
```bash
npm run dev
```

6. **Tarayıcıda açın**
```
http://localhost:3000
```

## 📖 Kullanım

### Dashboard
Ana kontrol paneli - tüm içerikleri görüntüleyin ve yönetin.

### Yeni İçerik Oluşturma
1. Dashboard'dan "Yeni İçerik Oluştur" butonuna tıklayın
2. İçerik tipini seçin (Masal, Ninni, Short)
3. "Oluştur" butonuna tıklayın
4. Sistem otomatik olarak:
   - Hikaye/ninni metnini oluşturur
   - TTS seslendirmesi yapar
   - Görselleri hazırlar
   - Arka plan müziği ekler
   - Video render eder
   - YouTube metadata'sını oluşturur

### Zamanlama
Günlük içerik planını görüntüleyin ve yayın saatlerini optimize edin:
- Sabah masalları: 08:00
- Akşam masalları: 19:00
- Ninniler: 20:00 - 22:00
- Shorts: 12:00, 16:00, 18:00

## 🎯 Günlük İçerik Planı

| Saat  | Tip    | Süre      | Açıklama                      |
|-------|--------|-----------|-------------------------------|
| 08:00 | Masal  | 15 dakika | Sabah kahvaltı masalı         |
| 12:00 | Short  | 1-2 dk    | Öğle arası eğlence            |
| 16:00 | Short  | 1-2 dk    | İkindi çayı hikayeleri        |
| 18:00 | Short  | 1-2 dk    | Akşam öncesi kısa içerik      |
| 19:00 | Masal  | 15 dakika | Uyku öncesi masal saati       |
| 20:00 | Ninni  | 3-5 dk    | İlk ninni                     |
| 21:00 | Ninni  | 3-5 dk    | Gece ninnisi                  |
| 22:00 | Ninni  | 3-5 dk    | Uyku ninnisi                  |

**Toplam**: 8 video/gün • 240 video/ay • ~50 dakika içerik/gün

## 🎨 İçerik Kalitesi

### Masallar
- Türk kültürüne uygun karakterler
- Eğitici mesajlar ve hayat dersleri
- Dostluk, paylaşım, cesaret temaları
- Renkli ve eğlenceli anlatım
- Çocukların hayal gücünü geliştiren

### Ninniler
- Rahatlatıcı melodi ve ritim
- Yavaş tempo, sakin ses
- Anne şefkati temalı
- Huzur verici görseller
- Profesyonel müzik eşliği

### Shorts
- Hızlı ve dinamik
- YouTube Shorts formatı (9:16)
- Viral potansiyeli yüksek
- Basit ve anlaşılır
- Eğlenceli karakterler

## 🔧 Teknik Detaylar

### Veritabanı Şeması
```typescript
// Contents table
- id: serial
- type: varchar (masal, ninni, short)
- title: varchar
- story: text
- targetDuration: integer (seconds)
- audioUrl: text
- videoUrl: text
- thumbnailUrl: text
- metadata: jsonb
```

### API Endpoints
- `POST /api/generate` - Yeni içerik oluştur
- `GET /api/contents` - Tüm içerikleri listele
- `GET /api/health` - Sistem durumu

### Ücretsiz Servisler
Bu proje **tamamen ücretsiz** çalışacak şekilde tasarlanmıştır:

1. **TTS**: Microsoft Edge TTS (ücretsiz, sınırsız)
2. **Görseller**: Stable Diffusion veya benzeri açık kaynak modeller
3. **Müzik**: YouTube Audio Library (telif hakkı yok)
4. **Video**: FFmpeg (açık kaynak)
5. **Hosting**: Vercel/Railway ücretsiz tier

## 📊 İstatistikler

### Aylık Üretim
- 60 Masal (30 saat içerik)
- 90 Ninni (6-7.5 saat içerik)
- 90 Short (2.25-3 saat içerik)
- **Toplam: 240 video, ~40 saat içerik**

### YouTube Optimizasyonu
- Çocuk güvenli içerik (Made for Kids)
- SEO optimize edilmiş başlıklar
- Türkçe etiketler ve açıklamalar
- Optimum yayın saatleri
- Thumbnail tasarımları

## 🎯 Hedef Kitle

- **Yaş**: 0-8 yaş arası çocuklar
- **Dil**: Türkçe konuşan aileler
- **Coğrafya**: Türkiye ve Türk diasporası
- **Platform**: YouTube, YouTube Kids

## 🛠️ Geliştirme Roadmap

### Faz 1 (Mevcut) ✅
- [x] Temel platform altyapısı
- [x] Hikaye oluşturma sistemi
- [x] Veritabanı şeması
- [x] Dashboard ve UI

### Faz 2 (Planlanan)
- [ ] TTS entegrasyonu (Edge TTS)
- [ ] Görsel oluşturma (Stable Diffusion)
- [ ] Video render pipeline (FFmpeg)
- [ ] Otomatik zamanlama sistemi

### Faz 3 (Gelecek)
- [ ] YouTube API entegrasyonu
- [ ] Otomatik yükleme
- [ ] Analytics ve raporlama
- [ ] A/B testing

### Faz 4 (İleri Seviye)
- [ ] Çoklu karakter seslendirme
- [ ] İnteraktif hikayeler
- [ ] Kullanıcı önerileri
- [ ] Premium içerik

## 📝 Lisans

Bu proje eğitim ve ticari kullanım için açık kaynaklıdır.

## 🤝 Katkıda Bulunma

Pull request'ler memnuniyetle karşılanır. Büyük değişiklikler için lütfen önce bir issue açın.

## 📧 İletişim

Sorularınız için issue açabilirsiniz.

---

**Not**: Bu platform tamamen ücretsiz servisler kullanarak çalışacak şekilde tasarlanmıştır. API key veya ödeme gerektirmez.

Made with ❤️ for Turkish children
